# Software_Eng
Repository that contains  all the code for ConnectCare Healthcare Database Software Engineering

## 1. Utilizing website
 1.Clone the Repository.  
 2.Enter the connectcare directory  
 3.Ensure that python 3 is the default version of python running.  
 4.Ensure that pip is installed.  
 5.Type the following command in terminal  
  `pip install -r requirements.txt`   
 6.Once all the requirements are installed type into the terminal    
  `python manage.py runserver`    
 7.Open another terminal window and type this   
  `python manage.py run_chat_server`
 

