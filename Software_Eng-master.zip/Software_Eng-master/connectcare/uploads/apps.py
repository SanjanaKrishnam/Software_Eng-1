from django.apps import AppConfig


class UploadsConfig(AppConfig):
    name = 'uploads'
