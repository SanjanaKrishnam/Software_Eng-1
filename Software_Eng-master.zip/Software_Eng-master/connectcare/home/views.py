from django.shortcuts import render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from profiledet.models import USERMODEL
import json
from django_private_chat.models import Dialog
from django.contrib.auth import get_user_model
from django.shortcuts import get_object_or_404
from rolepermissions.checkers import has_permission
from rolepermissions.roles import get_user_roles
from rolepermissions.roles import assign_role
from rolepermissions.checkers import has_role, has_permission
from rolepermissions.permissions import revoke_permission, grant_permission
from rolepermissions.checkers import has_object_permission
from rolepermissions.decorators import has_role_decorator, has_permission_decorator



@login_required()
#@has_role_decorator('doctor')
@has_permission_decorator('view_patients')
def pat(request):
    p = USERMODEL.objects.get(name = request.user.username)
    Users = User.objects.all()
    l = []
    for k in Users :
        if(has_object_permission('authorised_patient',request.user,k)):
            z = USERMODEL.objects.get(name = k.username)
            l.append(z)
    return render(request,'home/patres.html',{'name':p.aname,'stuff':l})

@login_required()
#@has_role_decorator('patient')
@has_permission_decorator('authorize')
def auth(request):
    p = USERMODEL.objects.get(name = request.user.username)
    if request.method == 'GET':
        sq = request.GET.get('docauth')
        sq = USERMODEL.objects.get(name = sq)
        if p.auth is None :
            p.auth = json.dumps([])
            p.save()
        if sq.auth is None:
            sq.auth = json.dumps([])
            sq.save()
        jd = json.decoder.JSONDecoder()
        k = jd.decode(sq.auth)
        if p.name not in k:
            k.append(p.name)
            sq.auth = json.dumps(k)
            sq.save()
            k = jd.decode(p.auth)
            k.append(sq.name)
            p.auth = json.dumps(k)
            p.save()
        #user = get_object_or_404(get_user_model(), username=sq.name)
        #Dialog.objects.create(owner = request.user, opponent = user)
        return render(request,'home/docprof.html',{'type':sq,'auth' : 1})

#@has_role_decorator(['patient','doctor'])
@has_permission_decorator('search')
@login_required()
def doc(request):
    #p = USERMODEL.objects.get(name = request.user.username)
    if request.method == 'GET':
        sq = request.GET.get('docpr')
        if sq == None:
            return HttpResponseRedirect('/home')
        if not User.objects.get(username = sq):
            return HttpResponseRedirect('/home')
        doctor = USERMODEL.objects.get(name = sq)      
        return render(request,'home/docprof.html',{'type':doctor,'auth' : has_object_permission('authorised_doctor',request.user,User.objects.get(username = sq))})

@login_required()
#@has_role_decorator(['patient'])
@has_permission_decorator('view_doctors')
def doct(request):
    p = USERMODEL.objects.get(name = request.user.username)
    Users = User.objects.all()
    l = []
    for k in Users :
        if(has_object_permission('authorised_doctor',request.user,k)):
            z = USERMODEL.objects.get(name = k.username)
            l.append(z)
    return render(request,'home/docres.html',{'name':p.aname,'stuff':l})


@login_required()
def main(request):
    p = USERMODEL.objects.filter(name = request.user.username)
    if not p:
        return HttpResponseRedirect("/profile")
    k = USERMODEL.objects.get(name = request.user.username)
    if request.method == 'GET':
        sq = request.GET.get('search_box')
        if sq !=None and sq.strip() :
            z = USERMODEL.objects.filter(name = sq,type = "Doctor")
            f = USERMODEL.objects.filter(aname = sq,type = "Doctor")
            g = USERMODEL.objects.filter(phno = sq, type = "Doctor")
            n = USERMODEL.objects.filter(qual = sq, type = "Doctor")
            p = USERMODEL.objects.filter(aname = sq, type = "Doctor")
            j = USERMODEL.objects.filter(field = sq, type = "Doctor")
            p = z|f|g|n|p|j
            return render(request,'home/rend.html',{'query':p,'name':sq})

    return render(request,'home/PAt.html',{'name':k.aname})

