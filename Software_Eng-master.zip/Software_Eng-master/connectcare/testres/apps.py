from django.apps import AppConfig


class TestresConfig(AppConfig):
    name = 'testres'
