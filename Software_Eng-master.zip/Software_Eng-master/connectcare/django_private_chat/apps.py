# -*- coding: utf-8
from django.apps import AppConfig


class DjangoPrivateChatConfig(AppConfig):
    name = 'django_private_chat'
