from django.contrib import admin
from .models import USERMODEL

admin.site.register(USERMODEL)
