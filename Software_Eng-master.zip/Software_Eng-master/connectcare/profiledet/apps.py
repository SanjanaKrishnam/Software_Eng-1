from django.apps import AppConfig


class ProfiledetConfig(AppConfig):
    name = 'profiledet'
