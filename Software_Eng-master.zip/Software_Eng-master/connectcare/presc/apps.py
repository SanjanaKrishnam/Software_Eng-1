from django.apps import AppConfig


class PrescConfig(AppConfig):
    name = 'presc'
