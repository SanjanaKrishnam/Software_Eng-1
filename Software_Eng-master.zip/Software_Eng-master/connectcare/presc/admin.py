from django.contrib import admin
from .models import Presc


# Register your models here.
